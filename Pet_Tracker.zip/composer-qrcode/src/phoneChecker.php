<?php

namespace Gruppe\Petlocator;

class phoneChecker
{
    public static function checkNumber(string $num) : bool{
        if (preg_match("/\+([0-9]){6,16}/", $num) === 1) {
            return true;
        } else {
            return false;
        }
    }
}