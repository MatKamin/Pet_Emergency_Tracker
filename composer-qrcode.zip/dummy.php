


Array(

    [files] => Array(
        [1] => Array(
            [attr] => Array(
                [source-language] => en
                [target-language] => de
                [data-type] => plaintext
            )
            [trans-units] => Array(
                [1] => Array(
                    [attr] => Array(
                        [id] => generate
                    )
                    [notes] => Array()
                    [source] => Array(
                        [raw-content] => Generate QR Code
                        [attr] => Array()
                    )
                    [target] => Array(
                        [raw-content] => Generiere QR Code
                        [attr] => Array()
                    )

                                )

                            [2] => Array
(
    [attr] => Array
    (
        [id] => name
    )

    [notes] => Array
(
)

[source] => Array
(
    [raw-content] => John Smith
[attr] => Array
(
)

                                        )

                                    [target] => Array
(
    [raw-content] => Max Mustermann
[attr] => Array
(
)

                                        )

                                )

                            [3] => Array
(
    [attr] => Array
    (
        [id] => number
    )

    [notes] => Array
(
)

[source] => Array
(
    [raw-content] => +4462916432
                                            [attr] => Array
(
)

                                        )

                                    [target] => Array
(
    [raw-content] => +4369912345678
                                            [attr] => Array
(
)

                                        )

                                )

                            [4] => Array
(
    [attr] => Array
    (
        [id] => generate
    )

    [notes] => Array
(
)

[source] => Array
(
    [raw-content] => Generate Now
[attr] => Array
(
)

                                        )

                                    [target] => Array
(
    [raw-content] => Jetzt Generieren
[attr] => Array
(
)

                                        )

                                )

                            [5] => Array
(
    [attr] => Array
    (
        [id] => generate
    )

    [notes] => Array
(
)

[source] => Array
(
    [raw-content] => Phonenumber:
                                            [attr] => Array
(
)

                                        )

                                    [target] => Array
(
    [raw-content] => Telefonnummer:
                                            [attr] => Array
(
)

                                        )

                                )

                            [6] => Array
(
    [attr] => Array
    (
        [id] => petName
    )

    [notes] => Array
(
)

[source] => Array
(
    [raw-content] => Pet Name:
                                            [attr] => Array
(
)

                                        )

                                    [target] => Array
(
    [raw-content] => Haustiername:
                                            [attr] => Array
(
)

                                        )

                                )

                            [7] => Array
(
    [attr] => Array
    (
        [id] => download
    )

    [notes] => Array
(
)

[source] => Array
(
    [raw-content] => Download
    [attr] => Array
(
)

                                        )

                                    [target] => Array
(
    [raw-content] => Herunterladen
    [attr] => Array
(
)

                                        )

                                )

                            [8] => Array
(
    [attr] => Array
    (
        [id] => generateNew
    )

    [notes] => Array
(
)

[source] => Array
(
    [raw-content] => Generate New
[attr] => Array
(
)

                                        )

                                    [target] => Array
(
    [raw-content] => Erneut Generieren
[attr] => Array
    …